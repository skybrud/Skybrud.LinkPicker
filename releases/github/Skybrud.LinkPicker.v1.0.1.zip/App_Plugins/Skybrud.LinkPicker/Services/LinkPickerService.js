﻿angular.module('umbraco.services').factory('skybrudLinkpickerService', function (dialogService) {

    var service = {
        
        parseUmbracoLink: function(e) {
            return {
                id: e.id || 0,
                name: e.name || '',
                url: e.url,
                target: e.target || '_self',
                mode: (e.id ? (e.isMedia ? 'media' : 'content') : 'url')
            };
        },
        
        addLink: function (callback) {
            dialogService.closeAll();
            dialogService.linkPicker({
                callback: function (e) {
                    if (!e.id && !e.url && !confirm('The selected link appears to be empty. Do you want to continue anyways?')) return;
                    if (callback) callback(service.parseUmbracoLink(e));
                    dialogService.closeAll();
                }
            });
        },
        
        editLink: function(link, callback) {
            dialogService.closeAll();
            if (link.mode == 'media') {

                dialogService.linkPicker({
                    currentTarget: {
                        name: link.name,
                        url: link.url,
                        target: link.target
                    },
                    callback: function (e) {
                        if (!e.id && !e.url && !confirm('The selected link appears to be empty. Do you want to continue anyways?')) return;

                        if (parseUmbracoLink(e).id == 0) {
                            e.id = link.id;
                            e.isMedia = true;

                        }

                        $scope.model.value[index] = parseUmbracoLink(e);
                        dialogService.closeAll();
                    }
                });
            } else {
                dialogService.linkPicker({
                    currentTarget: {
                        id: link.id,
                        name: link.name,
                        url: link.url,
                        target: link.target
                    },
                    callback: function (e) {
                        if (!e.id && !e.url && !confirm('The selected link appears to be empty. Do you want to continue anyways?')) return;
                        if (callback) callback(service.parseUmbracoLink(e)); 
                        dialogService.closeAll();
                    }
                });
            }
        }
        
    };

    return service;

});